import './Header.css';
import React from 'react';

const Header = () => {
    return (
        <>
            <div className="top-bar">
                <h1>Tienda</h1>
                <div className="separacion">
                <nav className="left-nav">
                    <a className="left" href="#mas-vendidos">Más Vendidos</a>
                    <a className="left" href="#nuevos">Nuevos</a>
                    <a className="left" href="#ofertas">Ofertas</a>
                </nav>
                <nav className="right-nav">
                    <a className="right" href="#ayuda">Ayuda</a>
                    <a className="right">
                        <button className="MiCuentaButton">Mi Cuenta</button>
                    </a>
                </nav>
                </div>
            </div>
            <div className="search-bar">
                <input type="text" placeholder="Buscar productos por nombre..." />
                <button>Buscar</button>
            </div>
        </>
    );
}

export default Header;